---
title: about
date: 2023-09-13 21:12:14
---

# 自我介紹
嗨我是ㄧ個~廢物~國中生
# 興趣
我喜歡看漫畫&動漫
我在學寫代碼
- [x] lua一點點
- [x] python
- [ ] c++
- [x] c#
- [ ] java
- [ ] rust

**想學3D建模**
- [ ] blender
- [ ] unity
- [ ] unreal
- [ ] 3dmax
- [ ] maya

 Banner source: 天使と街 by Stella
 Avatar source: カラフル by Stella